 <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>

                <li>
                    <a href="index.php" class="waves-effect">
                        <i class="bx bx-home-circle"></i><span class="badge badge-pill badge-info float-right"></span>
                        <span>Dashboard</span>
                    </a>
                </li>

               
               

              
              

               

                

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-user-circle"></i>
                        <span>Admin</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="listeadmin.php">Listes Admin</a></li>
                        <li><a href="Ajouteradmin.php">Ajouter Admin</a></li>
                        
                    </ul>
                </li>

                

                


                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-message-dots"></i>
                        <span>Message</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="email-inbox.php">Boite de reception</a></li>
                       
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store-alt"></i>
                        <span>Produits</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="listesproduits.php">Listes Produits</a></li>
                        <li><a href="Ajouterproduct.php">Ajouter Produits</a></li>
                        
                    </ul>
                </li>


                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-map-alt"></i>
                        <span>Coordonnee Contact</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="listescoordonnee.php">Listes Contact</a></li>
                        <li><a href="Ajoutercoordonnee.php">Ajouter Contact</a></li>
                        
                    </ul>
                </li>


                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-table"></i>
                        <span>Recette</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="listesrecette.php">listes  Recette</a></li>
                        <li><a href="ajouterrecette.php">Ajouter  Recette</a></li>
                        
                        
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-file"></i>
                        <span>Pages</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                    <li><a href="listes.php">Listes Savez_vous</a></li>
                    <li><a href="ajoutersavezvous.php">Ajouter Savez vous</a></li>
                    <li><a href="listesqsn.php">Listes Qui_somme_nous</a></li>
                        
                        <li><a href="Ajouterqui_somme_nous.php">Ajouter Qui somme nous</a></li>
                        
                    </ul>
                </li>

                


             

              
             <!--   <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-aperture"></i>
                        <span>Icons</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="icons-boxicons.html">Boxicons</a></li>
                        <li><a href="icons-materialdesign.html">Material Design</a></li>
                        <li><a href="icons-dripicons.html">Dripicons</a></li>
                        <li><a href="icons-fontawesome.html">Font awesome</a></li>
                    </ul>
                </li>-->

               

                <li>
                

            </ul>
        </div>