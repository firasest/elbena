<footer>
					<div class="container">
						<div class="row">
							<div class="col-sm-5">
								<ul class="list-group">
									<li class="list-group-item style-1 list-group-label">Nos fromages</li>
                                    <li class="list-group-item style-1"><a href="products.php#filter=*">Tous les produits</a></li>
                                    <li class="list-group-item style-1"><a href="products.php#filter=.rape">Râpé</a></li>
                                    <li class="list-group-item style-1"><a href="products.php#filter=.pate-presse">Pâte pressé</a></li>
                                    <li class="list-group-item style-1"><a href="products.php#filter=.pate-file">Pâte filé</a></li>
                                    <li class="list-group-item style-1"><a href="products.php#filter=.pate-molle">Pâte molle</a></li>
                                    <li class="list-group-item style-1"><a href="products.php#filter=.pate-fraiche">Pâte fraîche</a></li>
                                    <li class="list-group-item style-1"><a href="products.php#filter=.a-base-alimentaire">Préparation alimentaire</a></li>

								</ul>    	
							</div>
							<div class="col-sm-4">
								<ul class="list-group">
									<li class="list-group-item style-1 list-group-label">Présentation</li>
                                    <li class="list-group-item style-1"><a href="qui-somme-nous.php">Qui sommes-nous ?</a></li>
                                    <li class="list-group-item style-1"><a href="le-saviez-vous.php">Le saviez-vous ?</a></li>
								</ul>    	
							</div>
							<div class="col-sm-3 col-xs-12">
                                <center>
                                    <ul class="list-group">
                                        <li class="list-group-item style-1 list-group-label">Réseaux Sociaux </li>
                                    </ul>
                                </center>
                                <center id="fb">
                                 <a href="https://twitter.com" class="icon-button twitter" target="_blank"><i class="icon-twitter"></i><span></span></a>
                                 <a href="https://www.facebook.com/Fromage-Fiore-344785575533009/" class="icon-button facebook" target="_blank"><i class="icon-facebook"></i><span></span></a>
                                 <a href="https://plus.google.com" class="icon-button google-plus" target="_blank"><i class="icon-google-plus"></i><span>
                                     
                                 </span>
                             </a>
                             <a href="ref.php" style="color: #074529;">.</a>
                             
                                </center>
								   	
							</div>
						</div>
						
						<div class="row">
							<div class="col-sm-4 col-sm-offset-4 pad-v text-center">
								<img alt="logo" data-src="images/logo-Fiore-fr-foncé-footer.png" class="img-responsive1 lazy" srcset="images/logo-Fiore-fr-foncé-footer.png 1x, images/logo-Fiore-fr-foncé-footer.png 2x">
							</div>
						</div>
						
					</div>
                </footer>