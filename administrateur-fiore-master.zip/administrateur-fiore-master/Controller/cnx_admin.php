<?php 

require_once('../Model/CnxAdmin.class.php');
//$id=$_GET['id'];
//$cnxAdmin = new CnxAdmin($_POST['login'], $_POST['password'], $_POST['email']);
//$admin = new CnxAdmin($_POST['login'],$_POST['password']);
$admin->verifier();
//header('location:../index.php');
//echo "oui";
//exit();
?>